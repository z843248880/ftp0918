#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: zhoujunlong
import os,sys

import json
acc_aaa = {
    "name": "aaa",
    "password": "123",
    "quota": 30000000
}
acc_bbb = {
    "name": "bbb",
    "password": "123",
    "quota": 30000000
}

# user_path = os.path.dirname(os.path.abspath(__file__))
# print(user_path)
# with open("%s/users/bbb.json" % user_path, "w") as f:
#     json.dump(acc_dic2, f)
# file_name = "%s/users/bbb.json" % user_path
#
# with open(file_name, 'r') as f:
#     aaa = json.load(f)
# print(aaa["name"])